
Greenwood Library

About

This is a simple Greenwood Public Library Website. It displays library sections, gallery, membership plans, upcoming events and contact information.

Technologies Used

HTML

Tailwind CSS (CDN)

JavaScript

Features

Displays library information

Provides responsive navigation bar

Shows different library sections

Displays library spaces in gallery

Includes membership plans

Shows reader testimonials

Displays upcoming events

Provides contact information

Includes mobile navigation menu

Uses hover effects and smooth transitions

Operations Performed

1 Display Library Sections

Displays different library collections such as Fiction, Children's, Science, History, Art and Research.

2 Explore Gallery

Displays images of different library spaces.

3 Membership Plans

Shows Basic, Student and Family membership plans.

4 View Events

Displays upcoming library events with dates and images.

5 Mobile Navigation

Allows users to open and close the navigation menu on mobile devices.

6 Dynamic Year

Displays the current year automatically in the footer using JavaScript.

How to Run

Create a folder named Greenwood Library.

Create index.html and script.js files.

Add the respective code to each file.

Keep all files in the same folder.

Open index.html in a browser.

Project Files

index.html

script.js

README.md

Author

Yash
