
const menuBtn = document.getElementById("menuBtn");
const mobileMenu = document.getElementById("mobileMenu");

menuBtn.addEventListener("click", function () {
    mobileMenu.classList.toggle("hidden");

    if (mobileMenu.classList.contains("hidden")) {
        menuBtn.innerHTML = "☰";
    } else {
        menuBtn.innerHTML = "✕";
    }
});

const mobileLinks = mobileMenu.querySelectorAll("a");

mobileLinks.forEach(function (link) {
    link.addEventListener("click", function () {
        mobileMenu.classList.add("hidden");
        menuBtn.innerHTML = "☰";
    });
});

// Current Year
const year = document.getElementById("year");

year.textContent = new Date().getFullYear();
